#!/usr/bin/perl
use List::Util qw[min max];
# this is script take the output from ms.pl (genealogies) to generate the sequence files
=for comments
perl seq-gen.pl 1 800 1 AJB/007/019/shallow.G;
perl seq-gen.pl 1 800 1 007/019/deep.G;
=cut

if(($ARGV[0]=="-help")||($#ARGV <=2)){
    print STDOUT "Parameters are:\n";
    print STDOUT "number of replicates per genealogy\n";#number of datamatrix for each geneanlogy
    print STDOUT "length of each locus\n";
    print STDOUT "scale factor \-s \n";#basically the theta for each genealogy.
    print STDOUT "genealogy file\n";# the file with Genealogies
    print STDOUT "output file(optional)\n";
    die "use -help to check parameters\n";

}
print "Hello, World...\n";
print STDOUT "simulating $ARGV[0] sequence set per genealogy\n";
print STDOUT "total sequence length is $ARGV[1]\n";
print STDOUT "scale factor is  $ARGV[2]\n";
print STDOUT "genealogies in file \'$ARGV[3]\'\n";
if($#ARGV>=4) {print STDOUT "output file is \'$ARGV[4]\'\n";}


my $genealogyfile=$ARGV[3];
(my $outfile=$genealogyfile) =~ s/\.G/\.Seq/;
if($#ARGV>=4) {$outfile= $ARGV[4];}

my $seqgenstr='./seq-gen -mHKY -l '.$ARGV[1].' -n '.$ARGV[0]. ' -z '.int(rand(99999)).' -s '.$ARGV[2].' -a0.8 -g4 -f0.3 0.2 0.3 0.2 -t3.0 <'.$genealogyfile.' >'.$outfile.';';
#print STDOUT $seqgenstr;<STDIN>;
system($seqgenstr);

#`./seq-gen -mHKY -l1000 -n$rep -z $randseed -s $rate -a0.8 -g4 -f0.3 0.2 0.3 0.2 -t3.0 -on <$dir/$genealogy/$genealogy_file >$dir/$genealogy/$sequence_file`;
