#!/usr/bin/perl
=for comment
perl raxml_seqgen.pl AJB/007/019/shallow.Seq 4;

=cut
my $infile=$ARGV[0];
my $cores=$ARGV[1];
print STDOUT $infile."\n".$cores."\n";
$infile =~ /^(.+)\.Seq/;
(my $prefix=$1) =~ s/\//_/g;
(my $besttreefile=$infile) =~ s/\.Seq/\.bestMLTrees/;
(my $boottreefile= $infile) =~ s/\.Seq/.bootTrees/;
open BTREE, ">$besttreefile";
open BOOTTREE, ">$boottreefile";
open INFILE, "<$infile";
while(my $line=<INFILE>){
	$line =~ /(\d+) (\d+)/;
	my $taxnum=$1;
	my $length=$2;
	my $tempphyfile=$prefix.'.phylip';
	open TEMPP, ">$tempphyfile";
	print TEMPP $line;
	until($taxnum==0){
		$line=<INFILE>;
		print TEMPP $line;
		$taxnum--;
	}
	close TEMPP;
	$outfilename=$prefix;
	my $command= "raxmlHPC-PTHREADS-SSE3  -f a -s $tempphyfile -e 0.001 -m GTRGAMMA -o outgroup -x 939374 -p 939374 -n $outfilename -T $cores -N 100;";
	#print STDOUT $command."\n";
	#last;
	
	system($command);
	system("rm RAxML_info.".$outfilename);
	open INTREE, "<RAxML_bestTree.".$outfilename;
	my $besttree=<INTREE>;
	close INTREE;
	system("rm RAxML_bestTree.".$outfilename);
	print BTREE $besttree;
	open INTREE, "<RAxML_bootstrap.".$outfilename;
	my @boottree=<INTREE>;
	close INTREE;
	print BOOTTREE join("",@boottree);
	system("rm RAxML_bootstrap.".$outfilename);
	system("rm  RAxML_bipartitions.".$outfilename);
	system("rm  RAxML_bipartitionsBranchLabels.".$outfilename);
	if(-e $prefix.'.phylip.reduced'){system("rm ".$prefix.'.phylip.reduced;')}
	#last;
}
system("rm ".$prefix.'.phylip');
close BTREE;
close INFILE;
close BOOTTREE;