library(ape)
library(phangorn)
library(stringr)
args = commandArgs(trailingOnly=TRUE)
repfolder=args[1]

extend.external.branch<-function(phy,add.depth=0){
  ntaxa=length(phy$tip.label)
  l<-which(phy$edge[,2]<=ntaxa)
  phy$edge.length[l]=phy$edge.length[l]+add.depth
  return(phy)
}

add.outgroup <- function(phy, root.node=NULL,new.depth=NULL){
  require(ape)
  
    th <- as.numeric(sort(branching.times(phy), decreasing=T))[1]
    re <- new.depth-th
    phy$root.edge <- re
    tt <- rtree(2)
    tt$edge.length <- c(0,0)
    tt$tip.label <- c("outgroup","drop")
    tt$root.edge <- th + re
    ot <- bind.tree(phy, tt, position=re)
    res <- drop.tip(ot, "drop")
    return(res)
 
}


g<-read.tree(paste(repfolder,"/g_trees.trees",sep=''))
  
for (i in 1:length(g)){
  g[[i]]$tip.label<-sub("_0_0$","",g[[i]]$tip.label,perl =T )
  g[[i]]$edge.length<-g[[i]]$edge.length/10
}

ng_shallow<-g
ng_deep<-g
for(i in 1:length(g)){
	ng_shallow[[i]]<-add.outgroup(g[[i]],new.depth=0.0875)
	ng_deep[[i]]<-extend.external.branch(g[[i]],add.depth=0.1875)
	ng_deep[[i]]<-add.outgroup(ng_deep[[i]],new.depth=0.3)
}
write.tree(ng_shallow,file=paste(repfolder,"/shallow.G",sep=''))
write.tree(ng_deep,file=paste(repfolder,"/deep.G",sep=''))